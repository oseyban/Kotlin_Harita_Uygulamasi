package com.os.kotlin_harita

import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.os.kotlin_harita.databinding.ActivityMapsBinding
import java.util.*

@Suppress("DEPRECATION")
class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var konumyonetici: LocationManager
    private lateinit var konumdinleyici: LocationListener
    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.setOnMapLongClickListener(dinleyici)

        // Add a marker in Sydney and move the camera
        //latitude=enlem
        //longitute=boylam

        /*
        //işaret koyma işlemleri
        val Ev = LatLng(39.7909312, 30.5224613)
        mMap.addMarker(MarkerOptions().position(Ev).title("Ev"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Ev))
        val Eskiev = LatLng(39.78593478057412, 30.517837974194332)
        mMap.addMarker(MarkerOptions().position(Eskiev).title("Eskiev"))
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(Eskiev))
        */
        konumyonetici=getSystemService(Context.LOCATION_SERVICE) as LocationManager

        konumdinleyici=object:LocationListener{
            override fun onLocationChanged(p0: Location) {

               //konum değişince yapılacak işlemler
                println(p0.latitude)
                println(p0.longitude)
                mMap.clear()    // bu komutu yazmazsak her yeni konum eklemede marker ekler. bu kod ile eski markerları siler
                val guncelkonum=LatLng(p0.latitude,p0.longitude)
                mMap.addMarker(MarkerOptions().position(guncelkonum).title("Güncel Konumunuz"))
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(guncelkonum,15f))

                //son güncellenen adresi listeler.
                val geocoder=Geocoder(this@MapsActivity, Locale.getDefault())
                try{
                    val adreslistesi=geocoder.getFromLocation(p0.latitude,p0.longitude,1)
                    if (adreslistesi != null) {
                        if(adreslistesi.isNotEmpty()){
                            println(adreslistesi.get(0).toString())
                        }
                    }


                }catch(e:java.lang.Exception){
                    e.printStackTrace()
                }
            }
        }
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            //izin verilmemiş
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),1)
        }else{
            //izin verilmiş
            konumyonetici.requestLocationUpdates(LocationManager.GPS_PROVIDER,1,1f,konumdinleyici)
            val sonkonum=konumyonetici.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if(sonkonum!=null){
                val sonkonumLATLANG=LatLng(sonkonum.latitude,sonkonum.longitude)
                mMap.addMarker(MarkerOptions().position(sonkonumLATLANG).title("Son Bilinen Konumunuz"))
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sonkonumLATLANG,15f))

            }
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if(requestCode==1){
            if(grantResults.isNotEmpty()){
                if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)
                    //izinverildi
                    konumyonetici.requestLocationUpdates(LocationManager.GPS_PROVIDER,1,1f,konumdinleyici)

            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
    val dinleyici=object:GoogleMap.OnMapLongClickListener{
        override fun onMapLongClick(p0: LatLng) {

            mMap.clear()
            val geocoder=Geocoder(this@MapsActivity,Locale.getDefault())
            if(p0!=null) {
                var adres = ""
                try {
                    val adreslistesi = geocoder.getFromLocation(p0.latitude, p0.longitude, 1)
                    if (adreslistesi != null) {
                        if (adreslistesi.size>0) {
                            if (adreslistesi.get(0).thoroughfare!=null) {
                                adres += adreslistesi.get(0).thoroughfare

                                if (adreslistesi.get(0).subThoroughfare!=null) {
                                    adres += adreslistesi.get(0).subThoroughfare

                                }
                            }

                        }
                    }


                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }
                mMap.addMarker(MarkerOptions().position(p0).title(adres))
            }

        }
    }
}